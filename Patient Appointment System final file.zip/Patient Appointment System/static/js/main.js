// Dark Mode Toggle (optional button: <button id="darkModeToggle">🌓</button>)
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("darkModeToggle");
  if (toggle) {
    toggle.addEventListener("click", () => {
      document.body.classList.toggle("dark-mode");
      localStorage.setItem("theme", document.body.classList.contains("dark-mode") ? "dark" : "light");
    });

    if (localStorage.getItem("theme") === "dark") {
      document.body.classList.add("dark-mode");
    }
  }

  // Accept Button
  document.querySelectorAll('.accept-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      fetch(`/api/appointments/${id}/accept`, { method: 'POST' })
        .then(res => res.json())
        .then(data => {
          if (data.status === 'success') {
            document.getElementById(`status-${id}`).innerText = 'Accepted';
            showToast('Appointment accepted!', 'success');
          }
        });
    });
  });

  // Reject Button
  document.querySelectorAll('.reject-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      fetch(`/api/appointments/${id}/reject`, { method: 'POST' })
        .then(res => res.json())
        .then(data => {
          if (data.status === 'success') {
            document.getElementById(`status-${id}`).innerText = 'Rejected';
            showToast('Appointment rejected.', 'danger');
          }
        });
    });
  });
});

// Toast Notification Function
function showToast(message, type = 'info') {
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.innerText = message;
  document.getElementById("toast-container").appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
