from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "default_secret")

# Upload configuration
UPLOAD_FOLDER = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'reports')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Max 16MB
ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Dummy doctor data for doctors.html
doctor = [
    {"name": "Dr. Asha Mehta", "specialization": "Cardiologist", "email": "asha@example.com", "phone": "9876543210", "available": "Mon - Fri, 10am to 4pm"},
    {"name": "Dr. Rakesh Singh", "specialization": "Dermatologist", "email": "rakesh@example.com", "phone": "9123456780", "available": "Tue - Sat, 12pm to 6pm"},
    {"name": "Dr. Neha Sharma", "specialization": "Pediatrician", "email": "neha@example.com", "phone": "9012345678", "available": "Mon, Wed, Fri - 9am to 2pm"}
]

# Database configuration
db_dir = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'database')
os.makedirs(db_dir, exist_ok=True)
db_path = os.path.join(db_dir, 'db.sqlite3')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_path}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# ------------------- MODELS -------------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150))
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    role = db.Column(db.String(20))  # 'patient' or 'doctor'

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    doctor_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    date = db.Column(db.String(20))
    time = db.Column(db.String(20))
    status = db.Column(db.String(20), default='pending')
    report_filename = db.Column(db.String(150), nullable=True)

    patient = db.relationship('User', foreign_keys=[patient_id])
    doctor = db.relationship('User', foreign_keys=[doctor_id])

# ------------------- ROUTES -------------------
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        role = request.form['role']

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("Email already registered.", "warning")
            return redirect(url_for('register'))

        new_user = User(name=name, email=email, password=password, role=role)
        db.session.add(new_user)
        db.session.commit()
        flash("Registration successful!", "success")
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['user_name'] = user.name
            session['user_role'] = user.role
            flash("Login successful!", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid credentials.", "danger")
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    role = session.get('user_role')
    user_id = session.get('user_id')

    if role == 'doctor':
        appointments = Appointment.query.filter_by(doctor_id=user_id).all()
    else:
        appointments = Appointment.query.filter_by(patient_id=user_id).all()

    return render_template('dashboard.html', appointments=appointments)

@app.route('/book', methods=['GET', 'POST'])
def book():
    if 'user_id' not in session or session['user_role'] != 'patient':
        return redirect(url_for('login'))

    doctors = User.query.filter_by(role='doctor').all()

    if request.method == 'POST':
        doctor_id = request.form.get('doctor')
        date = request.form.get('date')
        time = request.form.get('time')
        report = request.files.get('report')

        report_filename = None
        if report and allowed_file(report.filename):
            filename = secure_filename(report.filename)
            report_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            report.save(report_path)
            report_filename = filename

        new_appointment = Appointment(
            patient_id=session['user_id'],
            doctor_id=doctor_id,
            date=date,
            time=time,
            report_filename=report_filename
        )

        db.session.add(new_appointment)
        db.session.commit()
        flash("Appointment booked with report!", "success")
        return redirect(url_for('dashboard'))

    return render_template('book_appointment.html', doctors=doctors)

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for('login'))

@app.route('/doctors')
def show_doctors():
    return render_template("doctors.html", doctors=doctor)

# ------------------- API ENDPOINTS FOR DOCTOR ACTIONS -------------------
@app.route('/api/appointments/<int:appointment_id>/accept', methods=['POST'])
def accept_appointment(appointment_id):
    if 'user_id' not in session or session.get('user_role') != 'doctor':
        return jsonify({'error': 'Unauthorized'}), 403

    appt = Appointment.query.get(appointment_id)
    if not appt or appt.doctor_id != session['user_id']:
        return jsonify({'error': 'Invalid appointment'}), 404

    appt.status = 'accepted'
    db.session.commit()
    return jsonify({'status': 'success'})

@app.route('/api/appointments/<int:appointment_id>/reject', methods=['POST'])
def reject_appointment(appointment_id):
    if 'user_id' not in session or session.get('user_role') != 'doctor':
        return jsonify({'error': 'Unauthorized'}), 403

    appt = Appointment.query.get(appointment_id)
    if not appt or appt.doctor_id != session['user_id']:
        return jsonify({'error': 'Invalid appointment'}), 404

    appt.status = 'rejected'
    db.session.commit()
    return jsonify({'status': 'success'})

# ------------------- RUN -------------------
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)
